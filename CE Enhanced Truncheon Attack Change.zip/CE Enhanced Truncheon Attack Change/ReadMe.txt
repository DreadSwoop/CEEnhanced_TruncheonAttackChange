Hello,

This is the readme for the source files for the Truncheon Attack Change mod for Conan Exiles, Enhanced version.

DESCRIPTION OF CONTENTS

Contained within the accompanying folder are the various animation and data table files for the mods. The Animation subfolder contains the relevant animations, as you'd expect, alongside a few vestigial ones. There is also a sound folder with a few sound cues that are referenced by the animations. There are two data tables provided, one for merging the modded animations and other attack data into DT_ComboRules, and another for minor adjustments to the Truncheon's entry in WeaponUseTable, basically just the equip animation. Finally, the ModController which is used to perform the data table mergers is also present. 

The cover image has not been provided as that is my personal character; I'm sure you'll be able to come up with something on your own.

INSTALLATION

To add the mod into your DevKit, copy the 'GloryOfTruncheons' folder into the mod directory. From the main DevKit folder, the path will very likely be:

\CEUE5Devkit\UE4\Content\Mods

The mod should only need to be re-cooked (rebuilt) in the DevKit to become functional once again, unless Inflexion, Funcom, or whoever else decide to do some major renovations.

MISCELLANEOUS

If you're interested in testing the mod in advance of publishing or simply for your own use, you can copy the cooked pak file to the Mods folder in your game files and then enable in the main menu.

The pak file uses the name of the GloryOfTrunehcons folder in the DevKit and not the mod name in the DevKit's Info Panel. To change the name of the pak (if you want), you can copy the contents of the folder to one with the new name, though I would recommend NOT doing so as that will break all the references within the animations, requiring you to place them back together like a puzzle. As someone who's done that before, I'd recommend not doing it if at all possible. There are other, more convoluted ways of changing folder names, at least in Legacy, but you'll have to find that info on your own.

CONCLUSION

Hopefully that covers the basics, I look forward to seeing your version (don't screw it up)! If you decide to re-upload, let me know and I'll provide a link to your mod page.

Thanks for reading,

Dread Swoop
